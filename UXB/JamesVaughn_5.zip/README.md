To compile the project, 

  1. git clone https://github.com/vgbm/SoftwareCraftsmanship
  2. cd SoftwareCraftsmanship/UXB
  3. mkdir output && javac src/uxb/*.java -d output
